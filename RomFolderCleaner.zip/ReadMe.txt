Title = Rom Folder Cleaner
Author = djvj
Version = 1.0.8
;----------------------------------------------------------------------------
; Purpose: Moves roms and other Hyperspin Media that don't match your system's xml (database) out of your folders.
; Requires: RocketLauncher and at least one rom path set for that system in RocketLauncherUI - WILL NOT work with HyperLaunch.
; Hotkeys: Escape (Cancel Clean or Exit application)

; WARNING - This will overwrite files in the "%assetPath% (UNKNOWN)" folder if it already exists. Backup your roms and media first.

; Reads RocketLauncherUI Systems.xml or Hyperspin's Main Menu xml for systems
; Reads RocketLauncher system's Emulators.ini for Rom_Paths
; Logs everything to "Rom Folder Cleaner.log"
; Press the top ... button to define a custom xml to match your assets
; Press the bottom ... button to define a custom rom path to match your assets
; If you have multiple roms with the same name but different extensions, it will think these are good and keep these in your rom folder.
; ONLY works with console type roms with one file. Have not tested with roms in folders.

; Known issues:
; Mapped network drives may return garbage when reading from the path. Resolution: Run it on that pc, not through the network.
;----------------------------------------------------------------------------
